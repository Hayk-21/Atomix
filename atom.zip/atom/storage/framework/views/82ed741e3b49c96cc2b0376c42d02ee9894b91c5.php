<div class="login" id="modal1">
    <div class="content" id="modal1__content" style="overflow-x: unset !important;">
        <div class="main" style="overflow-x: hidden !important; z-index: 1">
            <span id="close-login">&times;</span>
            <div class="left__form" style="background:url('<?php echo e(asset('assets/src/img/right.webp')); ?>')"></div>
            <div class="right__form signin-form-container">

                <form method="POST" action="<?php echo e(route('login')); ?>" class="homepage-signin"><!-- home page sign in form -->
                    <?php echo csrf_field(); ?>
                    <div class="homepage-signin-email-password-container">
                        <span id="heading" class="heading-signin">Sign in</span>

                        <label class="homepage-email-label">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="errorMsg"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span>Email</span>
                            <input type="email" name="email" class="signin-email <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>"  />
                        </label>
                        <label class="homepage-password-label">

                            <span>Password</span>
                            <input type="password" name="password"  class="homepage-signin-password <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  />
                        </label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="errorMsg"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="signin-b-container">
                            <div class="homepage-recapthca-container">
                                <div class="g-recaptcha homepage-recapthca"
                                     data-sitekey="6LcSwTcaAAAAAEjbbf1NzY4BEtOl-tSlzEzuZPB0"></div>
                            </div>
                            <div class="signin-question-container">
                                <div class="signin-button-container ">
                                    <button class="signin-button signin-button-homepage">Sign in</button>
                                </div>
                                <div class="registration-offer">
                                    Don’t have an account?
                                    <a href="<?php echo e(route('register')); ?>" class="registration-offer-link">Register</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\Ashot\Desktop\ATOM\atom\resources\views/app/layouts/login.blade.php ENDPATH**/ ?>