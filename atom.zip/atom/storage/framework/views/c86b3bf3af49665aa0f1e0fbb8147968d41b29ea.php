<div class="login" id="modal1">
    <div class="content" id="modal1__content" style="overflow-x: unset !important;">
        <div class="main" style="z-index: 1" style="overflow-x: hidden !important;">
            <span id="close-login">&times;</span>
            <div class="left__form" style="background:url('<?php echo e(asset('assets/src/img/right.webp')); ?>')"></div>
            <div class="right__form signin-form-container">

                <form method="POST" action="<?php echo e(route('login')); ?>" class="homepage-signin"><!-- home page sign in form -->
                    <?php echo csrf_field(); ?>
                    <div class="homepage-signin-email-password-container">
                        <span id="heading" class="heading-signin">Sign in</span>

                        <label class="homepage-email-label">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="error-msg" >
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span>Email</span>
                            <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>"  />
                        </label>
                        <label class="homepage-password-label">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="error-msg" >
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span>Password</span>
                            <input type="password" name="password"  class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  />
                        </label>

















                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Ashot\Desktop\ATOM\atom\resources\views/auth/login.blade.php ENDPATH**/ ?>