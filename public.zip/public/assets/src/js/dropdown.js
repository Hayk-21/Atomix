

// menu add remove class
// function hid() {
//     if($('.my_menu').hasClass("ul-flex")){
//         $('.my_menu').removeClass('ul-flex');
//     }
//     else $('.my_menu').addClass('ul-flex');
// }

// $(".header .menu ul li a").click(function(e) {
//     e.preventDefault();
//     $(".header .menu ul li a").removeClass('active');
//     $(this).addClass('active');
// })

 // let buttons = document.querySelectorAll('.my_menu a');
 //    console.log(buttons);
 //    buttons.forEach(button => {
 //        button.addEventListener('click', function (){
 //            buttons.forEach(btn => btn.classList.remove('active'));
 //            this.classList.add('active');
 //        })
 //    })